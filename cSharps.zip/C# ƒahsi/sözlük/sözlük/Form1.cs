﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//dosyalama işlemler ve girdi çıktıi işlemleri

namespace sözlük
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void ekle_btn_Click(object sender, EventArgs e)
        {
            StreamWriter eng = File.AppendText("kelime.txt");
            StreamWriter tr = File.AppendText("anlamı.txt");

            eng.WriteLine(textBox1.Text);//ingilizce kelimeyi kaydetmek

            tr.WriteLine(textBox2.Text);//türkçe kelimeyi kaydetmek


            eng.Close();

            tr.Close();

        }

        private void bul_btn_Click(object sender, EventArgs e)
        {
            StreamReader eng = new StreamReader("kelime.txt");
            StreamReader tr = new StreamReader("anlamı.txt");


            

            int satır_index = 0;

            string eng_str = "";

            while ((eng_str= eng.ReadLine()) != null)
            {
               
                if (eng_str == textBox1.Text)
                {
                    
                    break;

                    
                }
                satır_index++;

            }
            int sayaç = 0;
            string satır = "";
            while ((satır= tr.ReadLine())!=null)
            {


                if (sayaç == satır_index)
                {
                    textBox2.Text=satır;
                    break;
                }
                sayaç++;


            }

            eng.Close();
            tr.Close();
        }
    }
}
