﻿namespace tambölünenbulucu
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.sayı_txt_box = new System.Windows.Forms.TextBox();
            this.BUL_btn = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // sayı_txt_box
            // 
            this.sayı_txt_box.Location = new System.Drawing.Point(240, 54);
            this.sayı_txt_box.Name = "sayı_txt_box";
            this.sayı_txt_box.Size = new System.Drawing.Size(124, 20);
            this.sayı_txt_box.TabIndex = 0;
            // 
            // BUL_btn
            // 
            this.BUL_btn.Location = new System.Drawing.Point(146, 54);
            this.BUL_btn.Name = "BUL_btn";
            this.BUL_btn.Size = new System.Drawing.Size(75, 23);
            this.BUL_btn.TabIndex = 1;
            this.BUL_btn.Text = "BUL";
            this.BUL_btn.UseVisualStyleBackColor = true;
            this.BUL_btn.Click += new System.EventHandler(this.BUL_btn_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(146, 111);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(218, 186);
            this.listBox1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(528, 386);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.BUL_btn);
            this.Controls.Add(this.sayı_txt_box);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox sayı_txt_box;
        private System.Windows.Forms.Button BUL_btn;
        private System.Windows.Forms.ListBox listBox1;
    }
}

