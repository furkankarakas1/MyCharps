#a="FATİH"
#b=[0,1,2,3,4]
#print(a[0])
#print(a[0],a[1])
#print(a[0],a[1],a[2])
#print(a[0],a[1],a[2],a[3])
#print(a[0],a[1],a[2],a[3],a[4])
######


#okutup consola yazdırma yazdırmak istiyosan r olan yere w yazıcan alt alta yazdırmak istiyosan a yazıcan ve file.write("..")
#file=open("çalışma saatim.txt","r")

#for adam in file:
    #print(adam)


#file.close()


# file=open("çalışma saatim.txt","r")


# for adam in file:


   # print(adam) 








class Account:

  def __init__(self,isim,numara,bakiye):
      self.isim = isim
      self.numara = numara
      self.bakiye = bakiye

  def hesapBilgileri(self):
      print("Name:",self.isim)
      print("Number:",self.numara)
      print("Salary:",self.bakiye)
  def tkMoney(self,miktar):
      if (self.bakiye - miktar <0):
          print("bakiye yetmiyo amca")
      
      else:
        self.bakiye -= miktar
        print("new quantity",self.bakiye)

  def putMon(self,miktar):
      self.bakiye +=miktar
      print("new quantity",self.bakiye)      
account = Account("delveloper self marketing",123456,1000)
account.hesapBilgileri()

account.putMon(500)