import random

a=0
tahmin=0
a=random.randint(0,1000)
sayaç=1
while(True):

    tahmin= int(input("tahmin gir:"))
    if(a==tahmin):
        print("tebrikler "+str(sayaç)+" seferde bildin")
        break
    elif(a>tahmin):

        print("daha büyük söylemelisin")
    elif(a<tahmin):
        print(" daha küçük söylemelisin")

    sayaç=sayaç+1
    





   

    

