file=open("çalışma saatim.txt","r")


for sa in file:
    print(sa)
file.close()

